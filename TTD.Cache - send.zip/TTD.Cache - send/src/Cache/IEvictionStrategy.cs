using System;
using TTD.Cache.Utilities;

namespace TTD.Cache{

    public interface IEvictionStrategy<TMeta>
    {
        TMeta Default { get; }

        //Create a new Meta for the accessed key.
        TMeta Touch(uint index, ReadOnlySlice<TMeta> metaSet);

        //Get the index of the key to the evict
        uint GetEvictionIndex(ReadOnlySlice<TMeta> metaSet);
    }
}