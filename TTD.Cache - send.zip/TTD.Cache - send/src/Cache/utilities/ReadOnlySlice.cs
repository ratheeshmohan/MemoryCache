using System;

namespace TTD.Cache.Utilities
{

    public struct ReadOnlySlice<T>
    {

        private readonly T[] _array;

        private readonly uint _startIndex;

        public ReadOnlySlice(T[] array) : this(array, 0)
        {
        }

        public ReadOnlySlice(T[] array, uint startIndex)
        {
            if (startIndex >= array.Length)
                throw new IndexOutOfRangeException(nameof(startIndex));

            _array = array;
            _startIndex = startIndex;
            Length = (uint)array.Length - startIndex;
        }

        public ReadOnlySlice(T[] array, uint startIndex, uint length)
        {
            if (length > array.Length - startIndex)
                throw new ArgumentException(nameof(length));

            _array = array;
            _startIndex = startIndex;
            Length = length;
        }

        public uint Length { get; }

        public bool IsEmpty => Length == 0;

        private uint EndIndex => _startIndex + Length - 1;

        public T this[uint index]
        {
            get
            {
                if (index > EndIndex)
                    throw new IndexOutOfRangeException(nameof(index));

                return _array[_startIndex + index];
            }
        }

        public T[] SubArray(uint start, uint end)
        {
            if (start > end)
                throw new IndexOutOfRangeException();
            if (end > EndIndex)
                throw new IndexOutOfRangeException(nameof(end));

            var subArray = new T[end - start + 1];
            for (uint i = start, x = 0; i <= end; ++i)
                subArray[x++] = _array[i];

            return subArray;
        }

        public T[] ToArray()
        {
            var newArray = new T[Length];
            for (uint i = _startIndex, x = 0, j = Length; j > 0; j--, i++, x++)
                newArray[x] = _array[i];
            return newArray;
        }
    }
}