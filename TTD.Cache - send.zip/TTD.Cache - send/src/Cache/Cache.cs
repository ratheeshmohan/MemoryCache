using System;
using Newtonsoft.Json;
using System.Security.Cryptography;
using System.Text;
using TTD.Cache.Utilities;

namespace TTD.Cache
{
    ///<summary>
    ///A Cache for storing arbitary type Keys and Values.
    ///</summary>
    ///<remarks>
    /// Keys are stored as byte array,each key is represented by  28 bytes structure{[0][1]..[27]#[28]..[55]#.....}
    /// Values are stored as array of TValue
    /// Metadatas are stored as array of TMeta.
    ///</remarks>
    public class Cache<TKey, TValue, TMeta> : ICache<TKey, TValue>
    {
        internal static class Sha256HashGenerator
        {
            public static byte[] GetHash(object data)
            {
                var jsonData = JsonConvert.SerializeObject(data);
                return SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(jsonData));
            }
        }

        private struct KeyDetails
        {
            public uint SetIndex;
            public byte[] HashTag;
        }

        private const uint TagBytesCount = 28;
        private readonly uint _length;
        private readonly uint _ways;
        private readonly uint _setCountLn2;
        private readonly byte[] _keys;
        private readonly TValue[] _values;
        private readonly TMeta[] _metas;
        private readonly IEvictionStrategy<TMeta> _evictionStrategy;
        private readonly IDataStore<TKey, TValue> _dataStore;

        ///<summary>
        ///Ctr for creating an instance.
        ///</summary>
        /// <param name="lengthPowOf2">Length of the cache,which should be an exact power of 2</param>
        /// <param name="nWaysPowOf2">Length of the set,which should be an exact power of 2</param>
        /// <param name="evictionStrategy">Strategy to fetch the meta details of the element access</param>
        /// <param name="dataStore">Original data store</param>
        public Cache(uint lengthPowOf2, uint nWaysPowOf2,
            IEvictionStrategy<TMeta> evictionStrategy, IDataStore<TKey, TValue> dataStore)
        {
            if (lengthPowOf2 < 1 || !IsPowerOfTwo(lengthPowOf2))
                throw new ArgumentException("Argument must be >0 and pow of 2");
            if (nWaysPowOf2 < 1 || !IsPowerOfTwo(nWaysPowOf2))
                throw new ArgumentException("Argument must be >0 and pow of 2");
            if (evictionStrategy == null)
                throw new ArgumentNullException(nameof(evictionStrategy));
            if (dataStore == null)
                throw new ArgumentNullException(nameof(dataStore));

            _length = lengthPowOf2;
            _ways = nWaysPowOf2;
            _evictionStrategy = evictionStrategy;
            _values = new TValue[_length];
            _metas = new TMeta[_length];
            _keys = new byte[_length * TagBytesCount];
            _setCountLn2 = (uint)Math.Log(_length / _ways, 2);
            _dataStore = dataStore;
            SetDefaultMeta();
        }

        public TValue Get(TKey key)
        {
            //Get Signature of Key
            var details = GetKeyDetails(key);

            var sIndex = details.SetIndex;
            var setBase = sIndex * _ways;
            var keysSetBase = setBase * TagBytesCount;
            //Searching all the elements in the slot sequentially, irrespective of the actual filled slot length.
            //This wont be a problem as N will be small( possibly <8) in ideal case. 
            //Note: If need, we can extend the Keys array yo include the filled length in first 4 bytes of Set.
            uint index = 0;
            var tagSlice = new ReadOnlySlice<byte>(details.HashTag, 0, TagBytesCount);
            for (var start = keysSetBase; index < _ways; ++index, start += TagBytesCount)
            {
                if (CompareSlices(tagSlice, new ReadOnlySlice<byte>(_keys, start, TagBytesCount)))
                    break;
            }

            if (index < _ways) //Hit
            {
                //Store new meta
                UpdateMeta(setBase, index);
                //Return Cached value
                return _values[sIndex + index];
            }
            //Miss
            //Get Eviction Index
            var slice = new ReadOnlySlice<TMeta>(_metas, sIndex, _ways);
            var evIndex = _evictionStrategy.GetEvictionIndex(slice);

            //Fetch value externally
            var newValue = _dataStore.GetValue(key);

            //Reset Store new value and reset Meta
            var location = setBase + evIndex;
            _metas[location] = _evictionStrategy.Default;
            _values[location] = newValue;

            //Store hash key
            var keyHashSlice = new Slice<byte>(_keys, keysSetBase + evIndex * TagBytesCount, TagBytesCount);
            for (uint x = 0; x < TagBytesCount; x++)
            {
                keyHashSlice[x] = details.HashTag[x];
            }

            //Update Meta for the Key
            UpdateMeta(setBase, evIndex);
            return newValue;
        }

        private void UpdateMeta(uint setBaseIndex, uint index)
        {
            var slot = setBaseIndex + index;
            _metas[slot] = _evictionStrategy.Touch(index, new ReadOnlySlice<TMeta>(_metas, setBaseIndex, _ways));
        }

        private KeyDetails GetKeyDetails(TKey key)
        {
            var hashBytes = Sha256HashGenerator.GetHash(key);
            var hashLast32Bit = BitConverter.ToUInt32(new[] { hashBytes[28], hashBytes[29], hashBytes[30], hashBytes[31] }, 0);
            //Get SetIndex
            var setIndex = _setCountLn2 == 0 ? 0 : hashLast32Bit % (0xFFFFFFFF >> (int)(32 - _setCountLn2));

            //Signature of Index 
            var tag = new byte[28];
            Array.Copy(hashBytes, 0, tag, 0, 27);
            return new KeyDetails { SetIndex = setIndex, HashTag = tag };
        }

        private void SetDefaultMeta()
        {
            var defaultMeta = _evictionStrategy.Default;
            for (var i = 0; i < _length; ++i)
                _metas[i] = defaultMeta;
        }

        private static bool CompareSlices<T>(ReadOnlySlice<T> a, ReadOnlySlice<T> b)
        {
            if (a.Length != b.Length)
                return false;

            var result = true;
            for (uint i = 0; i < a.Length && result; ++i)
                result &= a[i].Equals(b[i]);

            return result;
        }

        private static bool IsPowerOfTwo(uint n)
        {
            return (n & (n - 1)) == 0;
        }
    }
}