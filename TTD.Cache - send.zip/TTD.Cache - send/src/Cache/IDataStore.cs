namespace TTD.Cache{
    
    public interface IDataStore<in TKey, out TValue>
    {
        TValue GetValue(TKey key);
    }
}