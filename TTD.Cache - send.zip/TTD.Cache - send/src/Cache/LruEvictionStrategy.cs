using System;
using TTD.Cache.Utilities;

namespace TTD.Cache
{
    public class LruEvictionStrategy : IEvictionStrategy<long>
    {
        public long Default => long.MaxValue;

        public long Touch(uint index, ReadOnlySlice<long> metaSet)
        {
            return DateTime.Now.Ticks;
        }

        public uint GetEvictionIndex(ReadOnlySlice<long> metaSet)
        {
            if(metaSet[0] == Default)
                return 0;

            uint leastIndex = 0;
            for(uint i = 1; i < metaSet.Length ; ++i)
            {
                if(metaSet[i] == Default)
                {
                    leastIndex = i;
                    break;
                }
                if(metaSet[i] < metaSet[leastIndex])
                {
                    leastIndex = i;
                }
            }
            return leastIndex;
        }

    }
}