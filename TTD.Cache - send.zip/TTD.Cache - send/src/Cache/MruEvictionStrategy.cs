using System;
using TTD.Cache.Utilities;

namespace TTD.Cache
{
    public class MruEvictionStrategy : IEvictionStrategy<long>
    {
        public long Default => 0;

        public long Touch(uint index, ReadOnlySlice<long> metaSet)
        {
            return DateTime.Now.Ticks;
        }
        
        public uint GetEvictionIndex(ReadOnlySlice<long> metaSet)
        {
            if(metaSet[0] == Default)
                return 0;

            uint highestIndex = 0;
            for(uint i = 1; i < metaSet.Length ; ++i)
            {
                if(metaSet[i] == Default)
                {
                    highestIndex = i;
                    break;
                }
                if(metaSet[i] > metaSet[highestIndex])
                {
                    highestIndex = i;
                }
            }
            return highestIndex;
        }

    }
}