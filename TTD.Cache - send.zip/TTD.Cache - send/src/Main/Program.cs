﻿using System;
using TTD.Cache;

namespace Main
{
    internal class TestDataStore : IDataStore<uint, uint>
    {
        public uint GetValue(uint key)
        {
            return key;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            uint rows = (uint)Math.Pow(2, 4);
            ICache<uint, uint> c = new Cache<uint, uint, long>(rows, 4, new LruEvictionStrategy(), new TestDataStore());

            //var c = new CacheObj<int,int,int>(rows,8,new LruEvictionStrategy());
            for (uint i = 0; i < rows; i++)
                c.Get(i);
            Console.WriteLine("-------------------------------------------");


            for (var i = rows - 1; i > 0; --i)
                Console.WriteLine("Key = {0} Value = {1}", i, c.Get(i));

            // Perform a collection of generation 0 only.
            GC.Collect(0);
            Console.WriteLine("Generation: {0}", GC.GetGeneration(c));
            Console.WriteLine("Total Memory: {0}", GC.GetTotalMemory(false));

            // Perform a collection of all generations up to and including 2.
            GC.Collect(2);
            Console.WriteLine("Generation: {0}", GC.GetGeneration(c));
            Console.WriteLine("Total Memory: {0}", GC.GetTotalMemory(false));


            Console.Write("*********");
            Console.Read();

        }
    }
}
